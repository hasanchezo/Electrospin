# Configuration for Malyan M150 hobbyking printer
# config without automatic bed level sensor
# or in other words, "as stock"
