
#include "ElectroSpin.h"

//Screen variables
NexDSButton Start_Button = NexDSButton(1, 3, "bt0");
NexDSButton LoadSy1_Button = NexDSButton(5, 0,  "b0");
NexNumber Nextion_vel1 = NexNumber(3, 12, "vel1");
NexNumber Nextion_vel2 = NexNumber(3, 13, "vel2");

char buffer[100] = {0};
NexTouch *nex_listen_list[] =
{
    &Start_Button,
	&Nextion_vel1,
	&Nextion_vel2,
    NULL
};

boolean buttonState;
String message;

//Motor Variables
#define timer_tick 40 //microseconds timer period
motor_control motor1(Motor1_Enable, Motor1_Step, Motor1_Dir, Motor1_Res, timer_tick);
motor_control motor2(Motor2_Enable, Motor2_Step, Motor2_Dir, Motor2_Res, timer_tick);
motor_control motorX(MotorX_Enable, MotorX_Step, MotorX_Dir, MotorX_Res, timer_tick);
motor_control motorY(MotorY_Enable, MotorY_Step, MotorY_Dir, MotorY_Res, timer_tick);


//Flow Control variables
unsigned long time;

void motor_handlers(void)
{
	motor1.motor_timer_handler();
	motor2.motor_timer_handler();
	motorX.motor_timer_handler();
	motorY.motor_timer_handler();
}

void bt0PopCallback(void *ptr)
{
    uint32_t dual_state;
    NexDSButton *btn = (NexDSButton *)ptr;
    dbSerialPrintln("b0PopCallback");
    dbSerialPrint("ptr=");
    dbSerialPrintln((uint32_t)ptr);
    memset(buffer, 0, sizeof(buffer));

    btn->getValue(&dual_state);
    if(dual_state)
    {
        dbSerialPrintln(" ON STATE");
        motor1.set_vel(100);
        motor1.enable();
        motor2.set_vel(100);
		motor2.enable();
    }
    else
    {
        dbSerialPrintln(" OFF STATE");
        motor1.disable();
        motor2.disable();
    }
}

double convertStepsSecTommMin(double stepsPerSec){
	double mmMin;
	//1.5mm per rev
	//200 steps per rev
	//60 secs per min
	mmMin=(1.5/200)*(60/stepsPerSec);
	return mmMin;
}

double convertmmMintoStepsSec(double mmMin){
	double stepsPerSec;
	stepsPerSec = (1.5/200)*(60/mmMin);
	return stepsPerSec;
}

void setup()
{
	//Init Communication with Nextion Touch Screen
	//nexInit do the Serial an Serial1 ports initialization
	nexInit();
	Start_Button.attachPush(bt0PopCallback, &Start_Button);

	Timer4.initialize(timer_tick);
	Timer4.attachInterrupt(motor_handlers);

	motor1.set_vel(0);//[steps/sec]
	motor1.set_dir(false);
	motor1.disable();
	motor2.set_vel(0);//[steps/sec]
	motor2.set_dir(false);
	motor2.disable();

	time=millis();

}


void loop()
{
	nexLoop(nex_listen_list);
	if((time-millis())>2000){
		double val=10;
		Serial.println(val);
		double temp = convertStepsSecTommMin(val);
		Serial.println(temp);
		Serial.println(convertmmMintoStepsSec(temp));

		time=millis();
	}
}
