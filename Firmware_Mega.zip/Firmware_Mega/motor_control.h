/*
 * motor_control.h
 *
 *  Created on: Mar 15, 2018
 *      Author: Bryan Salazar
 */

#ifndef MOTOR_CONTROL_H_
#define MOTOR_CONTROL_H_


class motor_control{
	int enable_pin_,step_pin_,dir_pin_;
	int resolution_;
	long time_tick_us_;
	double vel_steps_sec_=0;//[steps_sec]
	bool dir_=false;
	bool enable_positive_polarity = false;
	long half_step_us; //Time on one state
	long n_ticks; //Ticks to change state on step pin
	bool step_pin_state=false; //Switch state variable
	long state_counter=0; //Time keeping counter
public:
	motor_control(int enable_pin, int step_pin, int dir_pin, int resolution, long time_tick_us);
	void enable();
	void disable();
	void set_vel(double vel_steps_sec);
	double get_vel();
	void set_dir(bool dir);
	bool get_dir();
	void motor_timer_handler();
};



#endif /* MOTOR_CONTROL_H_ */
