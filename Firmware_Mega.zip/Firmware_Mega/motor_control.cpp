/*
 * motor_control.cpp
 *
 *  Created on: Mar 15, 2018
 *      Author: Bryan Salazar
 */
#include "motor_control.h"
#include "Arduino.h"

motor_control :: motor_control(int enable_pin, int step_pin, int dir_pin, int resolution, long time_tick_us)
	:enable_pin_(enable_pin), step_pin_(step_pin),dir_pin_(dir_pin),resolution_(resolution),time_tick_us_(time_tick_us)
{
	pinMode(enable_pin_,OUTPUT);
	pinMode(step_pin_,OUTPUT);
	pinMode(dir_pin_,OUTPUT);
	digitalWrite(dir_pin_,LOW);
	disable();
}

void motor_control :: enable()
{
	if(enable_positive_polarity){
		digitalWrite(enable_pin_,HIGH);
	}else{
		digitalWrite(enable_pin_,LOW);
	}
}

void motor_control :: disable()
{
	if(enable_positive_polarity){
		digitalWrite(enable_pin_,LOW);
	}else{
		digitalWrite(enable_pin_,HIGH);
	}
}

void motor_control :: set_vel(double vel_steps_sec){
	vel_steps_sec_=vel_steps_sec;
	half_step_us=(int)(1000000.0/(2*vel_steps_sec_*resolution_));
	n_ticks=(int)half_step_us/time_tick_us_;

	Serial.println(vel_steps_sec_);
	Serial.println(half_step_us);
	Serial.println(n_ticks);
}

double motor_control :: get_vel(void){
	return vel_steps_sec_;
}

void motor_control :: set_dir(bool dir){
	dir_ = dir;
	if(dir_){
		digitalWrite(dir_pin_,HIGH);
	}else{
		digitalWrite(dir_pin_,LOW);
	}
}

bool motor_control :: get_dir(void){
	return dir_;
}

void motor_control :: motor_timer_handler(void){
	if(state_counter>=n_ticks){

		//change polarity
		if(step_pin_state){
			step_pin_state=false;
		}else{
			step_pin_state=true;
		}
		if(step_pin_state){
			digitalWrite(step_pin_,HIGH);
		}else{
			digitalWrite(step_pin_,LOW);
		}
		//Reset Counter
		state_counter=0;
	}else{
		//Increment Counter
		state_counter++;
	}
}
