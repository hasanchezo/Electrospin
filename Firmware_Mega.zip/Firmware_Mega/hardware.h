/*
 * hardware.h
 *
 *  Created on: Mar 15, 2018
 *      Author: Bryan Salazar
 */

#ifndef HARDWARE_H_
#define HARDWARE_H_
#include "Arduino.h"
//**** RAMPS 1.4 Stepper Stick DRV8825  ***//

//RAMP->ElectroSPin
//DRIVER 0 -> MOTOR1
//DRIVER 1 -> MOTOR2
//DRIVER X -> MOTORX
//DRIVER Y -> MOTORY
//DRIVER Z -> N/A


#define Motor1_Enable	24
#define Motor1_Step		26
#define Motor1_Dir		28
#define Motor1_Res		32 // Microstep: 1/32

#define Motor2_Enable	30
#define Motor2_Step		36
#define Motor2_Dir		34
#define Motor2_Res		32 // Microstep: 1/32

#define MotorX_Enable	38
#define MotorX_Step		A0
#define MotorX_Dir		A1
#define MotorX_Res		32 // Microstep: 1/32

#define MotorY_Enable	A2
#define MotorY_Step		A6
#define MotorY_Dir		A7
#define MotorY_Res		32 // Microstep: 1/32



#endif /* HARDWARE_H_ */
