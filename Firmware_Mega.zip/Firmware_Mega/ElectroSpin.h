
#ifndef _ElectroSpin_H_
#define _ElectroSpin_H_
#include "Arduino.h"

#include "hardware.h"
#include "motor_control.h"
#include "TimerFour.h"
#include "Nextion.h"


#endif /* _ElectroSpin_H_ */
